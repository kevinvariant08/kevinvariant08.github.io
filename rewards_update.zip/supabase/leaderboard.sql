-- Friends leaderboard for the rewards page. Run once in the Supabase SQL Editor.
-- Anyone can read the board; each signed-in user can only write their own row,
-- and a row exists only while that user has opted in on the Rewards page.
create table if not exists public.leaderboard (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  name       text not null check (char_length(name) between 1 and 24),
  xp         integer not null default 0 check (xp between 0 and 10000000),
  week_xp    integer not null default 0 check (week_xp between 0 and 10000000),
  week       text,
  level      integer not null default 1 check (level between 1 and 500),
  streak     integer not null default 0 check (streak between 0 and 10000),
  updated_at timestamptz not null default now()
);

alter table public.leaderboard enable row level security;

drop policy if exists "leaderboard is public"   on public.leaderboard;
drop policy if exists "insert own leaderboard"  on public.leaderboard;
drop policy if exists "update own leaderboard"  on public.leaderboard;
drop policy if exists "delete own leaderboard"  on public.leaderboard;

create policy "leaderboard is public"  on public.leaderboard for select using (true);
create policy "insert own leaderboard" on public.leaderboard for insert with check (auth.uid() = user_id);
create policy "update own leaderboard" on public.leaderboard for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "delete own leaderboard" on public.leaderboard for delete using (auth.uid() = user_id);
