-- Problem-of-the-week discussion. Run once in the Supabase SQL Editor.
-- Anyone can read; signed-in users can post as themselves and delete their own posts.
create table if not exists public.discussion (
  id         bigint generated always as identity primary key,
  week       text not null,
  qid        text not null,
  user_id    uuid not null references auth.users(id) on delete cascade,
  name       text not null check (char_length(name) between 1 and 24),
  body       text not null check (char_length(body) between 1 and 2000),
  solved     boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists discussion_week_idx on public.discussion (week, created_at);

alter table public.discussion enable row level security;

drop policy if exists "discussion is public"   on public.discussion;
drop policy if exists "post as yourself"       on public.discussion;
drop policy if exists "delete your own posts"  on public.discussion;

create policy "discussion is public"  on public.discussion for select using (true);
create policy "post as yourself"      on public.discussion for insert with check (auth.uid() = user_id);
create policy "delete your own posts" on public.discussion for delete using (auth.uid() = user_id);
